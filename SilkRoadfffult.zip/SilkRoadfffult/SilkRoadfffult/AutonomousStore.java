public class AutonomousStore extends Store {

    private int routeLength;

    public AutonomousStore(String nombre, int location, int tenges, int routeLength) {
        super(nombre, location, tenges);
        this.routeLength = routeLength;
    }

    public int getRouteLength() {
        return routeLength;
    }

    public int chooseLocation(SilkRoad road) {
        int n = road.getRouteLength();
        int[] libres = new int[n];
        int contador = 0;
        for (int i = 0; i < n; i++) {
            if (road.findStoreAt(i) == null) {
                libres[contador] = i;
                contador++;
            }
        }
        if (contador == 0) return -1;

        int random = (int) (Math.random() * contador);
        return libres[random];
    }

    @Override
    public int getResistance() {
        return super.getResistance() + routeLength * 2;
    }
}
