public class FighterStore extends Store {

    public FighterStore(String nombre, int location, int tenges) {
        super(nombre, location, tenges);
    }

    @Override
    public int collectTenges(Robot visitante) {
        if (visitante == null) {
            return super.collectTenges(null);
        }
        if (visitante.getMoney() > getMonto()) {
            return super.collectTenges(visitante);
        }
        return 0;
    }

    @Override
    public boolean canBeVisitedBy(Robot visitante) {
        return visitante != null && visitante.getMoney() > getMonto();
    }

    @Override
    public int getResistance() {
        return super.getResistance() + 5;
    }
}