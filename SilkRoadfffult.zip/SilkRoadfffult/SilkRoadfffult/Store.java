public class Store {
    // Atributos visuales
    private Circle circulo;

    // Atributos lógicos
    private String nombre;
    private int tenges;
    private int location;
    private int initialTenges; // Para poder reabastecer

    // --- NUEVO CICLO 2 ---
    private int emptiedCount; // Contador de veces vaciada

    /**
     * Constructor para una Tienda.
     */
    public Store(String nombre, int location, int tenges) {
        this.nombre = nombre;
        this.tenges = tenges;
        this.initialTenges = tenges;
        this.location = location;

        // --- NUEVO CICLO 2 ---
        this.emptiedCount = 0;

        // --- GRÁFICOS (tu código) ---
        this.circulo = new Circle();
        this.circulo.changeColor("magenta");
        this.circulo.changeSize(40);
    }

    /** Mueve la tienda a la celda (x, y) y la hace visible. */
    public void mover(int x, int y, int tamCelda) {
        int centroX = x + (tamCelda - 40) / 2;
        int centroY = y + (tamCelda - 40) / 2;
        circulo.setPosition(centroX, centroY);
        circulo.makeVisible();
    }

    /** Oculta la tienda */
    public void makeInvisible() {
        circulo.makeInvisible();
    }

    // --- MÉTODOS LÓGICOS ---

    public int getLocation() {
        return location;
    }

    /**
     * NUEVO: Un robot recoge el dinero de la tienda.
     * La versión que recibe el visitante permite que subclases
     * tomen decisiones basadas en el robot.
     */
    public int collectTenges(Robot visitor) {
        int collected = this.tenges;
        if (collected > 0) {
            this.emptiedCount++; // Incrementa el contador
            circulo.changeColor("grey");
        }
        this.tenges = 0;
        return collected;
    }

    /**
     * VERSIÓN LEGACY para compatibilidad. Delegará al nuevo método.
     */
    public int collectTenges() {
        return collectTenges(null);
    }

    /** Reabastece la tienda a su monto inicial */
    public void resupply() {
        this.tenges = this.initialTenges;
        if (this.tenges > 0) {
            circulo.changeColor("magenta");
        }
    }

    public int getMonto() {
        return tenges;
    }

    public String getNombre() {
        return nombre;
    }

    /** NUEVO CICLO 2: Obtiene el contador de veces vaciada */
    public int getEmptiedCount() {
        return emptiedCount;
    }

    /**
     * ¿Puede ser visitada por este robot?
     * Por defecto verdadero; subclases (p. ej. FighterStore)
     * pueden sobreescribirlo.
     */
    public boolean canBeVisitedBy(Robot r) {
        return true;
    }
    
    public void setLocation(int newLocation) {
        this.location = newLocation;
    }
    
    public int getResistance() {
        return 0;
    }

}
