public class NeverBackRobot extends Robot {

    public NeverBackRobot(String nombre, int location) {
        super(nombre, location);
    }

    public void move(SilkRoad camino) {
        int nuevaPos = getLocation() + 1;
        if (nuevaPos < camino.getRouteLength()) {
            setLocation(nuevaPos);
            Rectangle celda = camino.findStoreAt(nuevaPos) != null ?
                camino.getCelda(nuevaPos) : null;
            if (celda != null) moveTo(celda.getxPosition(), celda.getyPosition());

            Store s = camino.findStoreAt(nuevaPos);
            if (s != null) {
                int recogido = s.collectTenges(this);
                addTenges(recogido);
            }
        }
    }
}